/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10288567_prog6112_exam_q1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the MovieTickets class, using JUnit framework.
 */
public class MovieTicketsTest {

    private MovieTickets movieTickets; // Instance of MovieTickets for testing

    @BeforeEach
    public void setUp() {
        // Initialize the MovieTickets instance before each test
        movieTickets = new MovieTickets();
    }

    /**
     * Tests the TotalMovieSales method by providing sample ticket sales data
     * and checking if the calculated total matches expected values.
     */
    @Test
    public void testTotalMovieSales() {
        int[] salesNapoleon = {3000, 1500, 1700}; // Expected total: 6200
        int[] salesOppenheimer = {3500, 1200, 1600}; // Expected total: 6300

        // Calculate totals using TotalMovieSales method
        int totalNapoleon = movieTickets.TotalMovieSales(salesNapoleon);
        int totalOppenheimer = movieTickets.TotalMovieSales(salesOppenheimer);

        // Verify that the calculated totals match expected totals
        assertEquals(6200, totalNapoleon, "Total sales for Napoleon should be 6200");
        assertEquals(6300, totalOppenheimer, "Total sales for Oppenheimer should be 6300");
    }

    /**
     * Tests the TopMovie method by checking that it returns the correct top-performing
     * movie name based on total sales values.
     */
    @Test
    public void testTopMovie() {
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6300}; // Oppenheimer has higher sales, should be top movie

        // Get the top movie and verify it matches the expected value
        String topMovie = movieTickets.TopMovie(movies, totalSales);
        assertEquals("Oppenheimer", topMovie, "Oppenheimer should be the top-performing movie");

        // Test for a tie case (both movies have the same sales)
        int[] equalSales = {5000, 5000};
        topMovie = movieTickets.TopMovie(movies, equalSales);
        assertEquals("Napoleon", topMovie, "If both have the same sales, the first movie (Napoleon) should be returned");
    }
}


/*
//Reference List

Title: Movie Tickets  sales Report - 2024 App
//Date: 12 November 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
website that could ,was adapted from to help code: /https://www.w3schools.com/java/java_arrays_multi.asp .
*/