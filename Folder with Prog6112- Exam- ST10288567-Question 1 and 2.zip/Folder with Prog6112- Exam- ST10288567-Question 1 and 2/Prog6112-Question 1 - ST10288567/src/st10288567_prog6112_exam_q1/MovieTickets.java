/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10288567_prog6112_exam_q1;

/**
 *
 * @author Darsh Somayi
 */
/**
 * Class that implements the IMovieTickets interface to calculate
 * total movie sales and determine the top-performing movie.
 */
public class MovieTickets implements IMovieTickets {

    /**
     * Sums the ticket sales for a given movie.
     * @param movieTicketSales Array of ticket sales per month for the movie.
     * @return The total ticket sales for the movie.
     */
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sales : movieTicketSales) {
            total += sales;
        }
        return total;
    }

    /**
     * Compares total sales for each movie and returns the name of the
     * top-performing movie with the highest total sales.
     * @param movies Array of movie names.
     * @param totalSales Array of total sales for each movie.
     * @return Name of the movie with the highest total sales.
     */
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int maxSalesIndex = 0;
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[maxSalesIndex]) {
                maxSalesIndex = i;
            }
        }
        return movies[maxSalesIndex];
    }
}


/*
//Reference List

Title: Movie Tickets  sales Report - 2024 App
//Date: 12 November 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
website that could ,was adapted from to help code: /https://www.w3schools.com/java/java_arrays_multi.asp .
*/