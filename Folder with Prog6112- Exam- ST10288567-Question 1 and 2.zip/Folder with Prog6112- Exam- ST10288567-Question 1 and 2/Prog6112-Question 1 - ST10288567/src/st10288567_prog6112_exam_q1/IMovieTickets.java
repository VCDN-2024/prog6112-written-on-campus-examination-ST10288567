/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10288567_prog6112_exam_q1;

/**
 *
 * @author Darsh Somayi
 */
/**
 * Interface defining methods for movie ticket sales calculations.
 */
public interface IMovieTickets {

    /**
     * Calculates the total ticket sales for a single movie.
     * @param movieTicketSales Array of ticket sales for each month.
     * @return The total ticket sales for the movie.
     */
    int TotalMovieSales(int[] movieTicketSales);

    /**
     * Identifies the top-performing movie based on total sales.
     * @param movies Array of movie names.
     * @param totalSales Array of total sales for each movie.
     * @return The name of the movie with the highest total sales.
     */
    String TopMovie(String[] movies, int[] totalSales);
}



/*
//Reference List

Title: Movie Tickets  sales Report - 2024 App
//Date: 12 November 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
website that could ,was adapted from to help code: /https://www.w3schools.com/java/java_arrays_multi.asp .
*/