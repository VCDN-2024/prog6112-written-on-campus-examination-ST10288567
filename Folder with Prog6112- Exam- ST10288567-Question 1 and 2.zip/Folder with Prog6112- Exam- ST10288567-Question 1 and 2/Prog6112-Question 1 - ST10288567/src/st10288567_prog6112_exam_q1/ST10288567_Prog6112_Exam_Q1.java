/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10288567_prog6112_exam_q1;

/**
 *
 * @author Darsh Somayi
 */
public class ST10288567_Prog6112_Exam_Q1 {

    /**
 * Main application class to generate a report of movie ticket sales.
 * It uses a 2D array to store sales data and calculates totals using the MovieTickets class.
 */
    public static void main(String[] args) {
        // Movie names and ticket sales data for each month (January, February, March)
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[][] ticketSales = {
            {3000, 1500, 1700}, // Sales for "Napoleon" in Jan, Feb, and Mar
            {3500, 1200, 1600}  // Sales for "Oppenheimer" in Jan, Feb, and Mar
        };

        // Create an instance of MovieTickets to perform calculations
        MovieTickets movieTickets = new MovieTickets();
        int[] totalSales = new int[movies.length];

        // Display report header
        System.out.println("Movie Tickets Sales Report - 2024\n");
        System.out.println("Month\t\tNapoleon\tOppenheimer");

        // Array to hold the month names
        String[] months = {"January", "February", "March"};

        // Loop through each month, display sales, and accumulate totals for each movie
        for (int i = 0; i < months.length; i++) {
            System.out.print(months[i] + "\t\t");
            for (int j = 0; j < movies.length; j++) {
                System.out.print("R " + ticketSales[j][i] + "\t\t");
                totalSales[j] += ticketSales[j][i];
            }
            System.out.println(); // Newline after each month
        }

        // Display total sales for each movie
        System.out.println();
        for (int i = 0; i < movies.length; i++) {
            System.out.println("Total movie ticket Sales for " + movies[i] + ": R " + totalSales[i]);
        }

        // Determine and display the top-performing movie based on sales
        String topMovie = movieTickets.TopMovie(movies, totalSales);
        System.out.println("\nTop-Performing Movie: " + topMovie);
    }
}


/*
//Reference List

Title: Movie Tickets  sales Report - 2024 App
//Date: 12 November 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
website that could ,was adapted from to help code: /https://www.w3schools.com/java/java_arrays_multi.asp .
*/
