/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10288567_prog6112_exam_q2;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Darsh Somayi
 */

public class MovieTicketAppTest {

    private MovieTicketApp app;

    @BeforeEach
    public void setUp() {
        app = new MovieTicketApp();
        app.setVisible(false);  // Keep the GUI hidden during testing
    }

    @Test
    public void testProcessTicket_ValidInput() {
        app.movieComboBox.setSelectedItem("Napoleon");
        app.ticketsField.setText("3");
        app.priceField.setText("100.0");

        app.processTicket();

        String expectedReport = "Movie Ticket REPORT\n\n" +
                "Movie Name: Napoleon\n" +
                "Movie Ticket Price: R 100.0\n" +
                "Number of Tickets: 3\n" +
                "Total Ticket Price: R 342.0";
        assertEquals(expectedReport, app.reportArea.getText().trim());
    }

    @Test
    public void testProcessTicket_InvalidInput() {
        app.movieComboBox.setSelectedItem("Napoleon");
        app.ticketsField.setText("0");  // Invalid number of tickets
        app.priceField.setText("100.0");

        app.processTicket();

        String expectedReport = "Invalid data entered. Please check the inputs.";
        assertEquals(expectedReport, app.reportArea.getText().trim());
    }

    @Test
    public void testClearFields() {
        app.ticketsField.setText("3");
        app.priceField.setText("100.0");
        app.reportArea.setText("Sample Report");

        app.clearFields();

        assertEquals("", app.ticketsField.getText());
        assertEquals("", app.priceField.getText());
        assertEquals("", app.reportArea.getText());
        assertEquals("Napoleon", app.movieComboBox.getSelectedItem());
    }

    @Test
    public void testSaveReport() {
        app.reportArea.setText("Test Report Content");

        // Invoke the save method
        app.saveReport();

        // Check if the report file was created and contains the expected content
        File file = new File("report.txt");
        assertTrue(file.exists());

        try (Scanner scanner = new Scanner(file)) {
            StringBuilder fileContent = new StringBuilder();
            while (scanner.hasNextLine()) {
                fileContent.append(scanner.nextLine()).append("\n");
            }
            assertEquals("Test Report Content\n", fileContent.toString().trim());
        } catch (FileNotFoundException e) {
            fail("Report file not found.");
        } finally {
            file.delete();  // Clean up the file after testing
        }
    }
}

}


/*
//Reference List

Title: Movie Tickets  sales Report - 2024 App
//Date: 12 November 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
website that could ,was adapted from to help code: /https://www.w3schools.com/java/java_arrays_multi.asp .
*/
