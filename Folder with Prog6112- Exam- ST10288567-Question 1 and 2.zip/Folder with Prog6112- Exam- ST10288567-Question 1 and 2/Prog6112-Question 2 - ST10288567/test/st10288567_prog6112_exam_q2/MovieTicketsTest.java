/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10288567_prog6112_exam_q2;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


/**
 *
 * @author Darsh Somayi
 */

public class MovieTicketsTest {

    private MovieTickets movieTickets;

    @BeforeEach
    public void setUp() {
        movieTickets = new MovieTickets();
    }

    @Test
    public void testCalculateTotalTicketPrice() {
        double totalPrice = movieTickets.CalculateTotalTicketPrice(3, 100.0);
        assertEquals(342.0, totalPrice, 0.01);  // Expected 3 tickets * 100.0 * 1.14
    }

    @Test
    public void testValidateData_ValidData() {
        MovieTicketsData data = new MovieTicketsData("Napoleon", 3, 100.0);
        assertTrue(movieTickets.ValidateData(data));
    }

    @Test
    public void testValidateData_InvalidMovieName() {
        MovieTicketsData data = new MovieTicketsData("", 3, 100.0);
        assertFalse(movieTickets.ValidateData(data));
    }

    @Test
    public void testValidateData_InvalidTicketPrice() {
        MovieTicketsData data = new MovieTicketsData("Napoleon", 3, -10.0);
        assertFalse(movieTickets.ValidateData(data));
    }

    @Test
    public void testValidateData_InvalidNumberOfTickets() {
        MovieTicketsData data = new MovieTicketsData("Napoleon", -3, 100.0);
        assertFalse(movieTickets.ValidateData(data));
    }
}



/*
//Reference List

Title: Movie Tickets  sales Report - 2024 App
//Date: 12 November 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
website that could ,was adapted from to help code: /https://www.w3schools.com/java/java_arrays_multi.asp .
*/
