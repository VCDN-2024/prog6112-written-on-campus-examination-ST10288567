/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10288567_prog6112_exam_q2;

/**
 *
 * @author Darsh Somayi
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class MovieTicketApp extends JFrame {
    private JComboBox<String> movieComboBox;
    private JTextField ticketsField, priceField;
    private JTextArea reportArea;
    private JMenuItem exitMenuItem, processMenuItem, clearMenuItem, saveReportMenuItem;

    public MovieTicketApp() {
        setTitle("Movie Ticket Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);  // Center the window

        // Set up main layout with GridBagLayout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);  // Padding around components
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // ComboBox for Movie selection
        JLabel movieLabel = new JLabel("Select Movie:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(movieLabel, gbc);
        
        movieComboBox = new JComboBox<>(new String[]{"Napoleon", "Oppenheimer", "Damsel"});
        gbc.gridx = 1;
        mainPanel.add(movieComboBox, gbc);

        // TextField for Number of Tickets
        JLabel ticketsLabel = new JLabel("Number of Tickets:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        mainPanel.add(ticketsLabel, gbc);
        
        ticketsField = new JTextField(10);
        gbc.gridx = 1;
        mainPanel.add(ticketsField, gbc);

        // TextField for Ticket Price
        JLabel priceLabel = new JLabel("Ticket Price (R):");
        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(priceLabel, gbc);
        
        priceField = new JTextField(10);
        gbc.gridx = 1;
        mainPanel.add(priceField, gbc);

        // TextArea for displaying report
        JLabel reportLabel = new JLabel("Movie Ticket Report:");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        mainPanel.add(reportLabel, gbc);
        
        reportArea = new JTextArea(10, 30);
        reportArea.setEditable(false);
        reportArea.setLineWrap(true);
        reportArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(reportArea);
        gbc.gridy = 4;
        mainPanel.add(scrollPane, gbc);

        // Add the main panel to the frame
        add(mainPanel, BorderLayout.CENTER);

        // Menu setup
        setupMenu();

        setVisible(true);
    }

    private void setupMenu() {
        JMenuBar menuBar = new JMenuBar();
        
        JMenu fileMenu = new JMenu("File");
        exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);

        JMenu toolsMenu = new JMenu("Edit");
        processMenuItem = new JMenuItem("Process");
        processMenuItem.addActionListener(e -> processTicket());
        clearMenuItem = new JMenuItem("Clear");
        clearMenuItem.addActionListener(e -> clearFields());
        saveReportMenuItem = new JMenuItem("Save Report");
        saveReportMenuItem.addActionListener(e -> saveReport());
        
        toolsMenu.add(processMenuItem);
        toolsMenu.add(clearMenuItem);
        toolsMenu.add(saveReportMenuItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    private void processTicket() {
        String movieName = (String) movieComboBox.getSelectedItem();
        int numberOfTickets;
        double ticketPrice;

        try {
            numberOfTickets = Integer.parseInt(ticketsField.getText());
            ticketPrice = Double.parseDouble(priceField.getText());
        } catch (NumberFormatException ex) {
            reportArea.setText("Please enter valid numbers for tickets and price.");
            return;
        }

        MovieTicketsData data = new MovieTicketsData(movieName, numberOfTickets, ticketPrice);
        MovieTickets movieTickets = new MovieTickets();

        if (movieTickets.ValidateData(data)) {
            double totalPrice = movieTickets.CalculateTotalTicketPrice(numberOfTickets, ticketPrice);
            reportArea.setText("Movie Ticket REPORT\n\n" +
                    "Movie Name: " + movieName + "\n" +
                    "Movie Ticket Price: R " + ticketPrice + "\n" +
                    "Number of Tickets: " + numberOfTickets + "\n" +
                    "Total Ticket Price: R " + totalPrice);
        } else {
            reportArea.setText("Invalid data entered. Please check the inputs.");
        }
    }

    private void saveReport() {
        try (PrintWriter writer = new PrintWriter("report.txt")) {
            writer.print(reportArea.getText());
            JOptionPane.showMessageDialog(this, "Report saved to report.txt");
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "Error saving report.");
        }
    }

    private void clearFields() {
        ticketsField.setText("");
        priceField.setText("");
        reportArea.setText("");
        movieComboBox.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MovieTicketApp::new);
    }
}



/*
//Reference List

Title: Movie Tickets  sales Report - 2024 App
//Date: 12 November 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
website that could ,was adapted from to help code: /https://www.w3schools.com/java/java_arrays_multi.asp .
*/
