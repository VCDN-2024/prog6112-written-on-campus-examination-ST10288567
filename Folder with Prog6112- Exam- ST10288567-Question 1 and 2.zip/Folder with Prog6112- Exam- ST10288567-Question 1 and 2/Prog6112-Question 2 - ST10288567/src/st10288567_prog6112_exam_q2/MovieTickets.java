/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10288567_prog6112_exam_q2;

/**
 *
 * @author Darsh Somayi
 */
public class MovieTickets implements IMovieTickets {
    private static final double VAT_RATE = 0.14;

    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        return numberOfTickets * ticketPrice * (1 + VAT_RATE);
    }

    @Override
    public boolean ValidateData(MovieTicketsData movieTicketsData) {
        if (movieTicketsData.getMovieName().isEmpty()) return false;
        if (movieTicketsData.getTicketPrice() <= 0) return false;
        if (movieTicketsData.getNumberOfTickets() <= 0) return false;
        return true;
    }
}


/*
//Reference List

Title: Movie Tickets  sales Report - 2024 App
//Date: 12 November 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
website that could ,was adapted from to help code: /https://www.w3schools.com/java/java_arrays_multi.asp .
*/
