/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10288567_prog6112_exam_q2;

/**
 *
 * @author Darsh Somayi
 */
public class MovieTicketsData {
    private String movieName;
    private int numberOfTickets;
    private double ticketPrice;

    public MovieTicketsData(String movieName, int numberOfTickets, double ticketPrice) {
        this.movieName = movieName;
        this.numberOfTickets = numberOfTickets;
        this.ticketPrice = ticketPrice;
    }

    public String getMovieName() { return movieName; }
    public int getNumberOfTickets() { return numberOfTickets; }
    public double getTicketPrice() { return ticketPrice; }
}


/*
//Reference List

Title: Movie Tickets  sales Report - 2024 App
//Date: 12 November 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
website that could ,was adapted from to help code: /https://www.w3schools.com/java/java_arrays_multi.asp .
*/
